const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const dirs=['tenues-temperees-01','tenues-arides-01','tenues-neige-01','tenues-jungle-01','tenues-marais-01','tenues-haillons-01','tenues-transports-tempere-01'];
const outfits=[];
for(const dir of dirs){
 const c=JSON.parse(fs.readFileSync(path.join(root,dir,'catalogue.json'),'utf8'));
 for(const m of c.models||c.outfits)for(const v of m.variants){
  const source=v.native||v.source,sex=v.sex||m.sex;
  const id=m.id+'-'+sex+'-'+v.palette;
  let hat=v.headwear;
  if(!hat&&v.allowedHeadwear?.some(h=>/^H\d/.test(h))){const h=v.allowedHeadwear.find(h=>/^H\d/.test(h));hat='couvre-chefs/natifs/'+h+'.aseprite';}
  outfits.push({id,cut:m.id,sex,label:m.label,biome:m.biome||c.biome||dir.match(/tenues-(.*?)-01/)[1].replace('temperees','tempere'),palette:v.palette,source:dir+'/'+source,example:dir+'/'+v.example,hat:hat?dir+'/'+hat:null,category:c.category||m.category||'civil',job:m.id==='TR01'?'groom':m.id==='TR02'?'load':m.id==='TR03'?'rope':m.id==='TR04'?'ledger':m.id.startsWith('E')?'carry':m.id.endsWith('01')?'hoe':m.id.endsWith('02')?'sow':m.id==='A04'?'pottery':m.id==='J03'?'weave':m.id==='J04'?'stir':m.id==='M03'?'net':m.id.endsWith('04')?'craft':'craft'});
 }
}
for(const v of outfits)for(const k of ['source','example','hat'])if(v[k]&&!fs.existsSync(path.join(root,v[k])))throw Error('Missing '+v[k]);
fs.mkdirSync(path.join(__dirname,'controle'),{recursive:true});
const hashes={};function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(e.name==='humains-animes-01')continue;const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.aseprite$/.test(p))hashes[path.relative(root,p).replaceAll('\\','/')]=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}}walk(root);
if(!fs.existsSync(path.join(__dirname,'controle/originaux-avant.json')))fs.writeFileSync(path.join(__dirname,'controle/originaux-avant.json'),JSON.stringify(hashes,null,2));
fs.writeFileSync(path.join(__dirname,'inventaire.json'),JSON.stringify({root:root.replaceAll('\\','/'),outfits},null,2));
const modules=[];
for(const sex of ['masculin','feminin']){
 for(const age of ['adulte','mur','age'])modules.push({id:sex+'-'+age,kind:'head',source:age==='adulte'?'humains-modulaires-propres/humain-'+sex+'-modulaire.aseprite':'visages-murs-ages/maitres/'+sex+'-'+age+'.aseprite'});
 const styles=sex==='masculin'?['01','02','05','06','07','08','09','10','11','12','13','14']:['01','02','03','04','05','07','08'];
 for(const style of styles){let dir='coiffures-collection';if(sex==='masculin'&&+style>=7)dir=+style<=10?'coiffures-masculines-07-10':'coiffures-masculines-11-14';if(sex==='feminin'&&+style>=7)dir='tenues-haillons-01/coiffures';modules.push({id:sex+'-hair-'+style,kind:'hair',source:dir+'/sources/brun/humain-'+sex+'-coupe-'+style+'.aseprite'});}
}
for(const e of fs.readdirSync(path.join(root,'barbes-moustaches-01/natifs/brun'))){if(e.endsWith('.aseprite'))modules.push({id:path.basename(e,'.aseprite'),kind:'beard',source:'barbes-moustaches-01/natifs/brun/'+e});}
for(const hat of new Set(outfits.map(v=>v.hat).filter(Boolean)))modules.push({id:path.basename(hat,'.aseprite'),kind:'hat',source:hat});
for(const m of modules)if(!fs.existsSync(path.join(root,m.source)))throw Error('Missing '+m.source);
fs.writeFileSync(path.join(__dirname,'modules.json'),JSON.stringify(modules,null,2));
console.log(JSON.stringify({outfits:outfits.length,silhouettes:new Set(outfits.map(v=>v.cut+'-'+v.sex)).size,originals:Object.keys(hashes).length,jobs:[...new Set(outfits.map(v=>v.job))]}));
