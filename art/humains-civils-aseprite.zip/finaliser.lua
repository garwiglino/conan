local out=assert(app.params.out)
local function read(n)local f=io.open(out..'/'..n,'r')local d=json.decode(f:read('*a'))f:close()return d end
local inv=read('inventaire.json')local meta=read('animation-index.json')local poses=dofile(out..'/poses.lua')
local function blank()return Image(80,80,ColorMode.RGB)end
local checks={files=0,frames=0,canonicalComparisons=0,mismatches={}}
app.fs.makeAllDirectories(out..'/premier-plan')
for _,v in ipairs(inv.outfits)do
 local entry=nil for _,e in ipairs(meta.outfits)do if e.id==v.id then entry=e break end end
 local s=app.open(out..'/natifs/'..v.id..'.aseprite')local source=app.open(inv.root..'/'..v.source)
 local head=0 local garment=10000
 for _,l in ipairs(source.layers)do if l.name=='07 Crane' or l.name=='08 Visage'then head=math.max(head,l.stackIndex)end if l.isVisible and (l.name:match('^HABIT') or l.name:match('^ANATOMIE'))then garment=math.min(garment,l.stackIndex)end if l.name:match('^COIFFE')or l.name:match('^MASQUE')then l.isVisible=false end end
 entry.headFirst=head<garment
 for d=1,4 do local expected=blank()expected:drawSprite(source,d)local actual=blank()actual:drawSprite(s,entry.frames.idle[d]+1)local different=0
  for y=0,79 do for x=0,79 do if expected:getPixel(x,y)~=actual:getPixel(x,y)then different=different+1 end end end
  checks.canonicalComparisons=checks.canonicalComparisons+1
  if different>0 then checks.mismatches[#checks.mismatches+1]={id=v.id,direction=d,pixels=different}end
 end source:close()
 local remove={}for _,l in ipairs(s.layers)do if l.name=='ANATOMIE - Mains devant le visage'then remove[#remove+1]=l end end for _,l in ipairs(remove)do s:deleteLayer(l)end
 local front=s:newLayer()front.name='ANATOMIE - Mains devant le visage'
 local sheet=Image(768,math.ceil(entry.count/16)*48,ColorMode.RGB)
 for id,starts in pairs(entry.frames)do for d,start in ipairs(starts)do for fi,p in ipairs(poses.clips[id].poses)do
  local frame=start+fi local im=blank()local hands=blank()
  for _,l in ipairs(s.layers)do local tool=l.name=='OUTILS - independants'local arm=(l.name:match('Manches')or l.name:match('Mains conservees')or l.name:match('Bras et mains')or l.name:match('bras')or l.name:match('Gants')) and (p.arms or 0)>=3
   if tool or arm then local c=l:cel(frame)if c then im:drawImage(c.image,c.position)if arm then hands:drawImage(c.image,c.position)end end end
  end
  if (p.arms or 0)>=3 then s:newCel(front,frame,hands,Point(0,0))end
  sheet:drawImage(Image(im,Rectangle(16,16,48,48)),Point(((frame-1)%16)*48,math.floor((frame-1)/16)*48))
 end end end
 sheet:saveAs(out..'/premier-plan/'..v.id..'.png')s:saveAs(out..'/natifs/'..v.id..'.aseprite')s:close()
 checks.files=checks.files+1 checks.frames=checks.frames+entry.count
end
local f=io.open(out..'/animation-index.json','w')f:write(json.encode(meta))f:close()
local f=io.open(out..'/controle/natifs.json','w')f:write(json.encode(checks))f:close()
print(json.encode(checks))
