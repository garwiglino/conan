-- Explicit contacts, passing poses and settles. Timings are in milliseconds.
local M={order={},clips={}}
local function clip(id,loop,durations,poses,stride)
 M.order[#M.order+1]=id M.clips[id]={loop=loop,durations=durations,poses=poses,stride=stride}
end
clip('idle',true,{450,220,350,260},{{},{breath=1},{breath=1,arms=1},{}})
local gait={{step=2,lift=0},{step=1,lift=1,breath=-1},{step=0,lift=1},{step=-1,lift=0,breath=1},{step=-2,lift=0},{step=-1,lift=-1,breath=-1},{step=0,lift=-1},{step=1,lift=0,breath=1}}
clip('walk',true,{100,90,90,100,100,90,90,100},gait,24)
local run={{step=3,lift=0,breath=-1},{step=2,lift=2,breath=-2},{step=0,lift=2,breath=-1},{step=-2,lift=0},{step=-3,lift=0,breath=-1},{step=-2,lift=-2,breath=-2},{step=0,lift=-2,breath=-1},{step=2,lift=0}}
for _,p in ipairs(run) do p.fear=true p.lean=1 p.arms=2 end
clip('flee',true,{75,65,65,75,75,65,65,75},run,32)
clip('startle',false,{90,65,110,180},{{breath=1},{breath=-1,arms=2,fear=true},{breath=-1,arms=3,fear=true},{arms=2,fear=true}})
clip('talk',true,{300,120,240,260},{{},{gesture=1},{gesture=2},{gesture=1}})
clip('sit_down',false,{120,100,90,100,160},{{},{sit=1,lean=1},{sit=2,lean=1},{sit=3},{sit=4}})
clip('seated',true,{600,240,400,360},{{sit=4},{sit=4,breath=1},{sit=4,breath=1,arms=1},{sit=4}})
clip('stand_up',false,{110,100,90,110,180},{{sit=4},{sit=3,lean=1},{sit=2,lean=1},{sit=1},{}})
clip('cower',true,{260,140,230,170},{{sit=1,arms=4,fear=true},{sit=1,arms=4,fear=true,lean=1},{sit=1,arms=4,fear=true},{sit=1,arms=4,fear=true,breath=1}})
clip('hit',false,{55,85,115,120,160},{{lean=-1,arms=1},{lean=-2,breath=1,arms=2,fear=true},{lean=-1,breath=1,arms=2},{lean=-1,arms=1},{}})
clip('death',false,{80,100,120,100,70,70,100,180},{{lean=-1,arms=2,fear=true},{sit=1,lean=-1,arms=2},{sit=3,lean=1,arms=1},{sit=3,angle=15},{sit=3,angle=38},{sit=2,angle=68},{sit=1,angle=90},{sit=1,angle=90,settle=1}})
local carry={} for i,p in ipairs(gait) do local q={} for k,v in pairs(p)do q[k]=v end q.load=true carry[i]=q end
clip('carry',true,{120,110,110,120,120,110,110,120},carry,20)
-- Work loops contain a held preparation, a faster useful gesture and recovery.
local jobs={
 hoe={{work=0},{work=1,lean=-1},{work=2,lean=-1},{work=3,lean=1},{work=4,lean=2,breath=1},{work=4,lean=2},{work=2,lean=1},{work=0}},
 sow={{work=0},{work=1},{work=2,lean=1},{work=3,lean=1},{work=4},{work=3},{work=1},{work=0}},
 craft={{work=0},{work=1},{work=2},{work=3,lean=1},{work=4,lean=1},{work=3},{work=1},{work=0}},
 pottery={{work=0,sit=2},{work=1,sit=2},{work=2,sit=2,lean=1},{work=3,sit=2,lean=1},{work=4,sit=2},{work=3,sit=2},{work=2,sit=2},{work=0,sit=2}},
 weave={{work=0},{work=1},{work=2,lean=1},{work=3},{work=4},{work=3,lean=1},{work=1},{work=0}},
 stir={{work=0},{work=1,lean=1},{work=2,lean=1},{work=3},{work=4},{work=3},{work=1},{work=0}},
 net={{work=0},{work=1},{work=2},{work=3,lean=1},{work=4},{work=3},{work=1},{work=0}},
 groom={{work=0},{work=1},{work=2,lean=1},{work=3,lean=1},{work=4},{work=3},{work=1},{work=0}},
 load={{work=0},{work=1,lean=1},{work=2,sit=2,lean=1},{work=3,sit=2,lean=1,load=true},{work=4,sit=1,load=true},{work=3,load=true},{work=1,load=true},{work=0}},
 rope={{work=0},{work=1,lean=1},{work=2,lean=1},{work=3,lean=-1},{work=4,lean=-1},{work=3},{work=1},{work=0}},
 ledger={{work=0},{work=1},{work=2,lean=1},{work=3,lean=1},{work=4},{work=3},{work=1},{work=0}}
}
for _,id in ipairs({'hoe','sow','craft','pottery','weave','stir','net','groom','load','rope','ledger'}) do clip(id,true,{260,180,150,90,160,180,140,240},jobs[id]) end
return M
