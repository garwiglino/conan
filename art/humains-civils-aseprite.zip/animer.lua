local out=assert(app.params.out)
local f=io.open(out..'/inventaire.json','r') local data=json.decode(f:read('*a')) f:close()
local poses=dofile(out..'/poses.lua') local dirs={'face','droite','dos','gauche'}
local function mkdir(p) app.fs.makeAllDirectories(p) end
mkdir(out..'/natifs') mkdir(out..'/exports') mkdir(out..'/apercus')
local function blank()return Image(80,80,ColorMode.RGB)end
local function ci(l,n)local im=blank() local c=l:cel(n) if c then im:drawImage(c.image,c.position) end return im end
local function rgba(h)return app.pixelColor.rgba(tonumber(h:sub(1,2),16),tonumber(h:sub(3,4),16),tonumber(h:sub(5,6),16),255)end
local O=rgba('100c14')
local function round(v)return math.floor(v+.5)end
local function pixel(im,x,y,p) x=round(x) y=round(y) if x>=0 and x<80 and y>=0 and y<80 then im:drawPixel(x,y,p)end end
local function line(im,x,y,X,Y,p,w)
 local n=math.max(math.abs(X-x),math.abs(Y-y),1)
 for t=0,n do for a=0,(w or 1)-1 do pixel(im,x+(X-x)*t/n+a,y+(Y-y)*t/n,p) end end
end
local function role(name)
 if name:match('07 Crane') or name:match('08 Visage') or name:match('^VISAGE') or name:match('^BARBE') or name:match('^MOUSTACHE') then return 'head' end
 if name:match('^CHEVEUX') or name:match('^ADAPTATION') then return 'hair' end
 if name:match('^COIFFE') or name:match('^MASQUE') then return 'hat' end
 if name:match('Manches') or name:match('Mains') or name:match('mains') or name:match('bras') or name:match('Bras') or name:match('Gants') then return 'arms' end
 if name:match('HABIT 10') or name:match('Pieds nus') then return 'feet' end
 if name:match('HABIT 11') or name:match('Jambes') then return 'legs' end
 return 'body'
end
local pixelCache=setmetatable({},{__mode='k'})
local function sourcePixels(src)
 local cached=pixelCache[src]if cached then return cached end cached={}
 for y=25,59 do for x=24,55 do local p=src:getPixel(x,y)if app.pixelColor.rgbaA(p)>0 then cached[#cached+1]={x,y,p,src:getPixel(x,y-1)}end end end
 pixelCache[src]=cached return cached
end
local function warp(src,name,p,d,fi,clip)
 local im=blank() local r=role(name) local side=d==2 or d==4 local sign=d==4 and -1 or 1
 local breathe=p.breath or 0 local sit=p.sit or 0 local lean=p.lean or 0 local step=p.step or 0
 local hx=side and lean*sign or 0 local by=breathe+round(sit*.65)
 local hair=name:match('Arriere') or name:match('Devant tunique')
 local function mapping(x,y)
  local X,Y=x,y local limb=x<40 and 1 or -1
  if r=='head' or r=='hat' or r=='hair' then
   X=x+hx Y=y+by
   if r=='hair' and hair and y>43 then X=X+round((y-43)/8*(step~=0 and -step*.3 or ((fi%4==2) and .6 or 0))) end
  elseif r=='arms' then
   local frac=math.max(0,math.min(1,(y-44)/3))
   local swing=side and -step*.65*sign or 0
   local up=(p.arms or 0)+(not side and math.max(0,-step*limb)*.35 or 0)
   local reach=0
   if p.gesture and (side or limb==-1) then up=p.gesture reach=side and p.gesture*sign or limb*-p.gesture end
   if p.work then
    local w=p.work up=({0,1,2,1,0})[w+1]
    if clip=='hoe' or clip=='craft' then up=({0,1,3,2,0})[w+1] end
    reach=side and (1+w*.35)*sign or -limb*math.min(2,w*.6)
   end
   if p.load then up=2 reach=side and 2*sign or -limb*2 end
   if p.fear then reach=side and sign or limb*.7 end
   local elbow=(up~=0 or reach~=0 or swing~=0) and math.sin(frac*math.pi)*(side and sign or limb)*.7 or 0
   X=x+hx+frac*(swing+reach)+elbow Y=y+by-frac*up
  elseif r=='feet' or r=='legs' then
   local frac=math.max(0,math.min(1,(y-48)/3)) local lift=p.lift or 0
   if side then
    X=x+round(step*frac*sign) Y=y-round(math.max(0,lift)*frac)
   else X=x Y=y-round(math.max(0,lift*limb)*frac)
   end
   if sit>0 then
    Y=y X=X+(side and round(sit*.65*frac)*sign or round(sit*.25*frac)*limb)
   end
   if y<49 then Y=Y+round(by*(49-y)/4) end
  else
   local top=math.max(0,math.min(1,(50-y)/5))
   X=x+round(hx*top) Y=y+round(by*top)
   -- The hem lags the pelvis; a straight apron is not pinched to the anatomy.
   if y>=48 and (name:match('HABIT 14') or name:match('Cape') or name:match('HABIT 12')) then
    X=X+round((y-47)*step*.12) Y=Y-round(math.max(0,sit-1)*(y-47)/7)
   end
  end
  return round(X),round(Y)
 end
 if side and (r=='feet' or r=='legs') and p.step and not p.far then
  local q={} for k,v in pairs(p)do q[k]=v end q.step=-step q.lift=-(p.lift or 0) q.far=true
  local far=warp(src,name,q,d,fi,clip)
  -- Keep the rear leg in the existing shadow ramp, rather than mirror its light.
  local shade=nil local value=10000
  for y=44,53 do for x=30,49 do local col=src:getPixel(x,y)if col~=O and app.pixelColor.rgbaA(col)>0 then local v=app.pixelColor.rgbaR(col)+app.pixelColor.rgbaG(col)+app.pixelColor.rgbaB(col)if v<value then shade=col value=v end end end end
  if shade then for it in far:pixels()do if it()~=O and app.pixelColor.rgbaA(it())>0 then it(shade)end end end
  im:drawImage(far)
 end
 for _,source in ipairs(sourcePixels(src)) do local x,y,color=source[1],source[2],source[3]
  local X,Y=mapping(x,y)
  if (r=='body' or r=='arms' or r=='legs') and y>25 then
   local above=source[4]
   if app.pixelColor.rgbaA(above)>0 then local ax,ay=mapping(x,y-1) local distance=math.max(math.abs(X-ax),math.abs(Y-ay))
    if distance>1 then for t=1,distance-1 do pixel(im,ax+(X-ax)*t/distance,ay+(Y-ay)*t/distance,t/distance<.5 and above or color)end end
   end
  end
  pixel(im,X,Y,color)
  -- The source trousers begin below the shirt. Fill the exposed waistband
  -- when the pelvis rises; this joins the independently authored layers.
  if r=='legs' and y==48 and breathe<0 then pixel(im,X,Y-1,color) end
 end
 if p.angle then
  local rotated=blank() local a=math.rad(p.angle) local ca,sa=math.cos(a),math.sin(a)
  -- Inverse nearest-neighbour sampling avoids pinholes in the fall silhouette.
  for y=20,64 do for x=16,66 do local px=x-40 local py=y-51-(p.settle or 0)
   local sx=round(40+px*ca+py*sa) local sy=round(51-px*sa+py*ca)
   if sx>=0 and sx<80 and sy>=0 and sy<80 then pixel(rotated,x,y,im:getPixel(sx,sy)) end
  end end im=rotated
 end
 return im
end
local function tool(p,d,id)
 local im=blank() if p.work==nil and not p.load then return im end
 local side=d==2 or d==4 local sg=d==4 and -1 or 1 local w=p.work or 0 local y=48+(p.sit or 0)
 local x=side and 44 or 40 local wood,light,iron=rgba('79533a'),rgba('c7a67a'),rgba('84989d')
 local function dot(xx,yy,col) if d==4 then xx=79-xx end pixel(im,xx,yy,col) end
 local function rect(xx,yy,ww,hh,col)for a=0,ww-1 do for b=0,hh-1 do dot(xx+a,yy+b,col)end end end
 local function ln(a,b,c,e,col) local n=math.max(math.abs(c-a),math.abs(e-b),1)for t=0,n do dot(a+(c-a)*t/n,b+(e-b)*t/n,col)end end
 if id=='carry' or p.load then rect(x-3,y-3,7,5,O) rect(x-2,y-3,5,4,wood) rect(x-2,y-3,5,1,light) rect(x,y-2,1,3,light)
 elseif id=='hoe' then local lift=({0,1,3,2,0})[w+1] ln(x-1,y-2-lift,x+5,y+2-lift,O) ln(x,y-2-lift,x+5,y+1-lift,wood) rect(x+3,y+1-lift,5,2,iron)
 elseif id=='craft' then rect(x,y+2,8,2,wood) rect(x+1,y+4,1,2,O) rect(x+6,y+4,1,2,O) local lift=({0,1,3,1,0})[w+1] ln(x,y-1-lift,x+3,y+1-lift,wood) rect(x-1,y-2-lift,3,2,iron)
 elseif id=='pottery' then rect(x-2,y+1,7,2,wood) rect(x-1,y-2,4,3,rgba('b77650')) rect(x,y-3,2,1,rgba('e0b887')) dot(x+((w%2)),y-2,light)
 elseif id=='sow' then rect(x-3,y-1,3,3,wood) if w>=2 then for k=1,3 do dot(x+k*2,y-1+k+(w-2),light)end end
 elseif id=='ledger' then rect(x-3,y-2,7,4,O) rect(x-2,y-2,5,3,rgba('dfc99c')) rect(x,y-2,1,3,wood) dot(x+1,y-1+(w%2),wood)
 elseif id=='groom' then rect(x,y-2+(w%3),3,2,wood) rect(x,y+(w%3),3,1,light)
 elseif id=='stir' then rect(x-2,y+1,7,3,wood) rect(x-1,y,5,1,light) ln(x+(w%3),y-3,x,y+1,wood)
 elseif id=='weave' then rect(x-2,y-1,6,4,wood) for a=0,2 do ln(x-2+a*2,y-1,x+a*2,y+2,light)end
 elseif id=='net' then for a=0,3 do ln(x-2+a*2,y-1,x-2+a*2,y+3,light)end for b=0,2 do ln(x-2,y-1+b*2,x+4,y-1+b*2,wood)end
 elseif id=='rope' then for k=0,6 do local a=k/6*math.pi*2 dot(x+2+math.cos(a)*3,y+math.sin(a)*2,light)end ln(x-2,y-2+(w%2),x+1,y,wood)
 end
 return im
end
local limit=app.params.modules and 0 or (tonumber(app.params.limit) or 1000) local selected=0 local result={clips={},outfits={}}
for _,id in ipairs(poses.order)do local c=poses.clips[id] result.clips[id]={durations=c.durations,loop=c.loop,stride=c.stride}end
for _,v in ipairs(data.outfits)do
 if selected<limit and (not app.params.only or v.id:find(app.params.only,1,true)) then
 selected=selected+1
 local src=app.open(data.root..'/'..v.source) local example=app.open(data.root..'/'..v.example)
 local layers={} for _,l in ipairs(src.layers)do if l.isVisible and not l.name:match('^COIFFE') and not l.name:match('^MASQUE') and not l.name:match('^CHEVEUX') then
  local q={name=l.name,images={}}for d=1,4 do q.images[d]=ci(l,d)end layers[#layers+1]=q
 end end
 -- The preview uses the approved assembly. Runtime hair remains a separate module.
 local extra={}for _,l in ipairs(example.layers)do if l.isVisible and (l.name:match('^CHEVEUX') or l.name:match('^ADAPTATION') or l.name:match('^COIFFE'))then
  local q={name=l.name,images={}}for d=1,4 do q.images[d]=ci(l,d)end extra[#extra+1]=q
 end end
 src:close()example:close()
 local s=Sprite(80,80,ColorMode.RGB) s.layers[1].name='OUTILS - independants' local prop=s.layers[1]
 for _,l in ipairs(layers)do l.target=s:newLayer()l.target.name=l.name end
 prop.stackIndex=#s.layers
 local order={}for _,id in ipairs(poses.order)do if not poses.clips[id].poses[1].work or id==v.job then order[#order+1]=id end end
 local total=0 for _,id in ipairs(order)do total=total+#poses.clips[id].poses*4 end
 local sheet=Image(16*48,math.ceil(total/16)*48,ColorMode.RGB)
 local previewSheet=Image(16*48,math.ceil(total/16)*48,ColorMode.RGB)
 local index={id=v.id,frames={},count=total}
 local frame=0
 for _,id in ipairs(order)do index.frames[id]={}
  local c=poses.clips[id]
  for d=1,4 do local start=frame+1 index.frames[id][d]=frame
   for fi,p in ipairs(c.poses)do frame=frame+1 if frame>1 then s:newEmptyFrame()end s.frames[frame].duration=c.durations[fi]/1000
    local body=blank() local head=blank() local preview=blank()
    for _,l in ipairs(layers)do local im=warp(l.images[d],l.name,p,d,fi,id) s:newCel(l.target,frame,im,Point(0,0))
     if role(l.name)=='head' then head:drawImage(im)else body:drawImage(im)end
    end
    local obj=tool(p,d,id) s:newCel(prop,frame,obj,Point(0,0))
    for _,l in ipairs(extra)do if l.name:match('Arriere')then preview:drawImage(warp(l.images[d],l.name,p,d,fi,id))end end
    preview:drawImage(body)
    for _,l in ipairs(extra)do if l.name:match('Devant tunique') or l.name:match('20') then preview:drawImage(warp(l.images[d],l.name,p,d,fi,id))end end
    preview:drawImage(head)
    for _,l in ipairs(extra)do if not l.name:match('Arriere') and not l.name:match('Devant tunique') and not l.name:match('20') then preview:drawImage(warp(l.images[d],l.name,p,d,fi,id))end end
    preview:drawImage(obj) body:drawImage(obj)
    local at=Point(((frame-1)%16)*48,math.floor((frame-1)/16)*48)
    sheet:drawImage(Image(body,Rectangle(16,16,48,48)),at) previewSheet:drawImage(Image(preview,Rectangle(16,16,48,48)),at)
   end
   local tag=s:newTag(start,frame) tag.name=id..'_'..dirs[d]
  end
 end
 s:saveAs(out..'/natifs/'..v.id..'.aseprite')s:close()
 sheet:saveAs(out..'/exports/'..v.id..'.png')previewSheet:saveAs(out..'/apercus/'..v.id..'.png')
 result.outfits[#result.outfits+1]=index print(v.id..' '..frame..' frames')
end
end
if not app.params.modules then local f=io.open(out..'/animation-index.json','w')f:write(json.encode(result))f:close() end
-- Module authoring shares the exact same per-pose deformation and frame timing.
return {warp=warp,poses=poses,role=role}
