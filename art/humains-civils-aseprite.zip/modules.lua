local out=assert(app.params.out)
local rig=dofile(out..'/animer.lua') local poses=rig.poses
local f=io.open(out..'/inventaire.json','r')local data=json.decode(f:read('*a'))f:close()
local f=io.open(out..'/modules.json','r')local modules=json.decode(f:read('*a'))f:close()
local dirs={'face','droite','dos','gauche'}
local function blank()return Image(80,80,ColorMode.RGB)end
local function ci(l,d)local im=blank()local c=l:cel(d)if c then im:drawImage(c.image,c.position)end return im end
app.fs.makeAllDirectories(out..'/modules-natifs')app.fs.makeAllDirectories(out..'/modules-exports')
local index={frames={},modules={}}local total=0
for _,id in ipairs(poses.order)do index.frames[id]={} for d=1,4 do index.frames[id][d]=total total=total+#poses.clips[id].poses end end
local H=math.ceil(total/16)*48 index.count=total index.planeHeight=H
for _,m in ipairs(modules)do
 local src=app.open(data.root..'/'..m.source) local ls={}
 for _,l in ipairs(src.layers)do local plane=nil
  if m.kind=='head' and l.isVisible and (l.name=='07 Crane' or l.name=='08 Visage' or l.name:match('^VISAGE')) then plane=1
  elseif m.kind=='hair' and l.name:match('^CHEVEUX') then plane=l.name:match('Arriere') and 1 or l.name:match('Devant tunique') and 2 or 3
  elseif m.kind=='beard' and (l.name:match('^BARBE') or l.name:match('^MOUSTACHE')) then plane=1
  elseif m.kind=='hat' then plane=l.name:match('^MASQUE') and 3 or l.name:match('20') and 1 or l.name:match('21') and 2 or nil end
  if plane then local q={name=l.name,plane=plane,images={}}for d=1,4 do q.images[d]=ci(l,d)end ls[#ls+1]=q end
 end src:close() assert(#ls>0,'Empty module '..m.id)
 local s=Sprite(80,80,ColorMode.RGB) local base=s.layers[1]
 for i,l in ipairs(ls)do l.target=i==1 and base or s:newLayer()l.target.name=l.name if l.name:match('^MASQUE')then l.target.isVisible=false end end
 local planes=m.kind=='hat' or m.kind=='hair' and 3 or 1 if type(planes)~='number'then planes=3 end
 local sheet=Image(768,H*planes,ColorMode.RGB) local frame=0
 for _,id in ipairs(poses.order)do local c=poses.clips[id]for d=1,4 do local start=frame+1
  for fi,p in ipairs(c.poses)do frame=frame+1 if frame>1 then s:newEmptyFrame()end s.frames[frame].duration=c.durations[fi]/1000
   local images={blank(),blank(),blank()}
   for _,l in ipairs(ls)do local im=rig.warp(l.images[d],l.name,p,d,fi,id) s:newCel(l.target,frame,im,Point(0,0))images[l.plane]:drawImage(im)end
   for plane=1,planes do sheet:drawImage(Image(images[plane],Rectangle(16,16,48,48)),Point(((frame-1)%16)*48,math.floor((frame-1)/16)*48+(plane-1)*H))end
  end
  local tag=s:newTag(start,frame)tag.name=id..'_'..dirs[d]
 end end
 s:saveAs(out..'/modules-natifs/'..m.id..'.aseprite')s:close() sheet:saveAs(out..'/modules-exports/'..m.id..'.png')
 index.modules[#index.modules+1]={id=m.id,kind=m.kind,planes=planes}
 print(m.id..' '..frame..' frames')
end
local f=io.open(out..'/modules-index.json','w')f:write(json.encode(index))f:close()
