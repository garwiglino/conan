Hearthreaver - animated civilian sources
216 editable Aseprite files with independent layers and four directions.
The included PNG exports and indexes can be rebuilt into the game with:
node scripts/build-civilian-art.cjs <extracted-directory>
The Lua authoring scripts document animation construction. Regenerating from the original static atelier requires its original paths in inventaire.json/modules.json.
